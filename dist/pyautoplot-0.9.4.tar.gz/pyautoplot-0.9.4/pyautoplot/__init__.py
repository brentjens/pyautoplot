__version__ = '0.9.4'

from pyautoplot.main import *
