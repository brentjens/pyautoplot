__version__ = '0.9.6'

from pyautoplot.main import *
