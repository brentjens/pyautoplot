__version__ = '0.9.3'

from pyautoplot.main import *
