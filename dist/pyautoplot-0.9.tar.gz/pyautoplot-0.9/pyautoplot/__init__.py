__version__ = '0.9'

from pyautoplot.main import *
