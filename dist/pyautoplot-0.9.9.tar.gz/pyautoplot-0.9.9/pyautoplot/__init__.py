__version__ = '0.9.9'

from pyautoplot.main import *
