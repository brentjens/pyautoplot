__version__ = '0.9.1'

from pyautoplot.main import *
