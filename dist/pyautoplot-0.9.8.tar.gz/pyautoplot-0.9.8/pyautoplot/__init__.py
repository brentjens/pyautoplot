__version__ = '0.9.8'

from pyautoplot.main import *
