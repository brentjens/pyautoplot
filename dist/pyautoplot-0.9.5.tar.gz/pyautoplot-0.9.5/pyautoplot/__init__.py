__version__ = '0.9.5'

from pyautoplot.main import *
